package ng.dwt.martins.examsys

import android.content.DialogInterface
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_intro.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class IntroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro)
        checkConnection()

        //adding a click listener to button
        ShowLoginBtn.setOnClickListener { startActivity(Intent(this, LoginActivity::class.java)) }
    }

    override fun onBackPressed() {
        //  super.onBackPressed()
        val builder = AlertDialog.Builder(applicationContext)
        builder.setMessage("Are you sure you want to exit?")
        builder.setCancelable(true)
        builder.setNegativeButton("NO", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        builder.setPositiveButton("EXIT", DialogInterface.OnClickListener {dialogInterface, i ->
            finish()
        })
        val alertDialog = builder.create()
        alertDialog.show()
    }

    private fun checkConnection() {
        val stringRequest = StringRequest(Request.Method.GET,
            Endpoints.API_CONNECT,
            Response.Listener<String> { s ->
                try {
                    val obj = JSONObject(s)
                    if (!obj.getBoolean("error")) {
                        Toast.makeText(applicationContext, obj.getString("message"), Toast.LENGTH_LONG).show()
                        ShowLoginBtn.isEnabled = true
                    } else {
                        Toast.makeText(getApplicationContext(), "Error In Connection", Toast.LENGTH_LONG).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }, Response.ErrorListener { volleyError -> Toast.makeText(applicationContext, volleyError.message, Toast.LENGTH_LONG).show() })

        //adding request to queue
        VolleySingleton.instance?.addToRequestQueue(stringRequest)
    }

}
