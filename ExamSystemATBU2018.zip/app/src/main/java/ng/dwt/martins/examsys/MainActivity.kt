package ng.dwt.martins.examsys

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressBar.visibility = View.VISIBLE

        val examsRecyclerView = findViewById(R.id.recyclerView) as RecyclerView
        examsRecyclerView.layoutManager = LinearLayoutManager(this)
        examsRecyclerView.hasFixedSize()
        val stringRequest = object : StringRequest(
            Request.Method.POST,
            Endpoints.API_GET_EXAMS,
            Response.Listener<String> { s ->
                try {
                    val obj = JSONObject(s)
                    val array = obj.getJSONArray("data")
                    progressBar.visibility = View.INVISIBLE
                    examsRecyclerView.adapter = ExamAdapter(array)
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }, object : Response.ErrorListener {
                override fun onErrorResponse(volleyError: VolleyError) {
                    Toast.makeText(applicationContext, volleyError.message, Toast.LENGTH_LONG).show()
                }
            }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params.put("userID", intent.getStringExtra("user_id"))
                return params
            }
       }
        VolleySingleton.instance?.addToRequestQueue(stringRequest)
    }

    class ExamAdapter(val exam: JSONArray) :
        RecyclerView.Adapter<ExamViewHolder>() {

        override fun onBindViewHolder(holder: ExamViewHolder, position: Int) {
            holder.bind(exam.getJSONObject(position), position)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExamViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.exam_all, parent, false)
            return ExamViewHolder(v)
        }
        override fun getItemCount(): Int = exam.length()
    }

    class ExamViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(exam:JSONObject, position: Int){
            val textCourseName = itemView.findViewById(R.id.course) as TextView
            val textSupervisor  = itemView.findViewById(R.id.supervisor) as TextView
//            val Venue = itemView.findViewById(R.id.venue) as TextView
            val textVenue = itemView.findViewById(R.id.venue) as TextView
            val textDate  = itemView.findViewById(R.id.date) as TextView

            textCourseName.text = exam["course"].toString()
            textSupervisor.text = "Supervisor: " + exam["supervisor"].toString()
            textVenue.text = "Venue: " + exam["venue"].toString() + " (Seat No: " + exam["seat_num"] + ")"
            textDate.text = "Date: " + exam["date"].toString()
        }
    }
}