package ng.dwt.martins.examsys

import android.content.DialogInterface
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_login.*
import org.json.JSONException
import org.json.JSONObject
import android.content.Intent
import android.support.v7.app.AlertDialog

class LoginActivity : AppCompatActivity() {

    private var userID: EditText? = null
    private var pass: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //getting it from xml
        userID = findViewById(R.id.studID) as EditText
        pass = findViewById(R.id.uniqPhrase) as EditText

        //adding a click listener to button
        goToReg.setOnClickListener { startActivity(Intent(this, RegActivity::class.java)) }

        loginBtn.setOnClickListener { getApiResponse() }
    }


    private fun getApiResponse() {
        val studID = userID?.text.toString()
        val password = pass?.text.toString()
        //check for empty strings
        if(userID?.text.isNullOrEmpty()) userID?.error = "Your ID cannot be empty"
        if(pass?.text.isNullOrBlank()) pass?.setError("Please input your password")
        //create volley string request
        val stringRequest = object : StringRequest(
            Request.Method.POST, Endpoints.API_LOGIN,
            Response.Listener<String> { response ->
                try {
                    val obj = JSONObject(response)
                    if (!obj.getBoolean("error")){
                        Toast.makeText(applicationContext, obj.getString("message"), Toast.LENGTH_LONG).show()
                        //Start New Intent
                        val i = Intent(this, MainActivity::class.java)
                        i.putExtra("user_id", obj.getInt("userID").toString())
                        startActivity(i)
                    }else{
                        Toast.makeText(applicationContext, obj.getString("message"), Toast.LENGTH_LONG).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            object : Response.ErrorListener {
                override fun onErrorResponse(volleyError: VolleyError) {
                    Toast.makeText(applicationContext, volleyError.message, Toast.LENGTH_LONG).show()
                }
            }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params.put("studID", studID)
                params.put("password", password)
                return params
            }
        }
        //adding request to queue
        VolleySingleton.instance?.addToRequestQueue(stringRequest)
    }
}
