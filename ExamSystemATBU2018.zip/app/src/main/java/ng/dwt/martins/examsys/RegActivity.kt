package ng.dwt.martins.examsys

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Toast
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_reg.*
import org.json.JSONException
import org.json.JSONObject

class RegActivity : AppCompatActivity() {

    private var name: EditText? = null
    private var uniqID: EditText? = null
    private var password: EditText? = null
    private var cpassword: EditText? = null
    private var level: Spinner? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reg)

        regBtn.setOnClickListener { registerNewMember() }
    }

    fun registerNewMember() {
        val name = name?.text.toString()
        val uniqID = uniqID?.text.toString()
        val password = password?.text.toString()
        val cpassword = cpassword?.text.toString()
        val level = level?.selectedItem.toString()
        val member_type = if (staff.isChecked) "staff" else "student"

        if (password !== cpassword) {
            rPass.error = "Passwords Don't Match"

        }
            //create volley string request
            val stringRequest = object : StringRequest(
                    Request.Method.POST, Endpoints.API_REG,
                    Response.Listener<String> { response ->
                        try {
                            val obj = JSONObject(response)
                            if (!obj.getBoolean("error")) {
                                Toast.makeText(applicationContext, obj.getString("message"), Toast.LENGTH_LONG).show()
                                //Start New Intent
                                val i = Intent(this, MainActivity::class.java)
                                i.putExtra("user_id", obj.getInt("userID").toString())
                                startActivity(i)
                            } else {
                                Toast.makeText(applicationContext, obj.getString("message"), Toast.LENGTH_LONG).show()
                            }
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        }
                    },
                    object : Response.ErrorListener {
                        override fun onErrorResponse(volleyError: VolleyError) {
                            Toast.makeText(applicationContext, volleyError.message, Toast.LENGTH_LONG).show()
                        }
                    }) {
                @Throws(AuthFailureError::class)
                override fun getParams(): Map<String, String> {
                    val params = HashMap<String, String>()
                    params.put("name", name)
                    params.put("unique_id", uniqID)
                    params.put("level", level)
                    params.put("unique_phrase", password)
                    params.put("member_type", member_type)
                    return params
                }
            }
            //adding request to queue
            VolleySingleton.instance?.addToRequestQueue(stringRequest)
        }
    }
