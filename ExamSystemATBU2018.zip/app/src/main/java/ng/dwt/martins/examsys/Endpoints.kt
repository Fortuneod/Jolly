package ng.dwt.martins.examsys

object Endpoints {
    private val API_URL = "http://192.168.43.80:80/examsys/public/api"
    val API_LOGIN = API_URL + "/login"
    val API_REG = API_URL + "/register"
    val API_GET_EXAMS = API_URL + "/exams"
    val API_CONNECT = API_URL + "/connect"
}