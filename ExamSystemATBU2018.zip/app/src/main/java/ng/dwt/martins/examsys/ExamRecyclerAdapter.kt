package ng.dwt.martins.examsys

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.RecyclerView.ViewHolder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlinx.android.synthetic.main.exam_all.view.*
import org.json.JSONArray
import org.json.JSONObject

class ExamRecyclerAdapter(private val exam: JSONArray) :
    RecyclerView.Adapter<ExamRecyclerAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExamRecyclerAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.exam_all, parent, false)
        return ViewHolder(v)
//        val inflatedView = parent.inflate(R.layout.exam_all)
//        return ViewHolder(inflatedView)
    }

    override fun getItemCount(): Int = exam.length()

    override fun onBindViewHolder(holder: ExamRecyclerAdapter.ViewHolder, position: Int) {
        holder.bind(exam.getJSONObject(position),position)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

//        private var view:View = itemView
//        private var exam:Exam? = null

        fun bind(exam:JSONObject, position: Int){
//            this.exam = exam
            val textCourseName = itemView.findViewById(R.id.course) as TextView
            val textSupervisor  = itemView.findViewById(R.id.supervisor) as TextView
            textCourseName.text = exam["course"].toString()
            textSupervisor.text = exam["supervisor"].toString()
//            view.course.text = exam.course
//            view.supervisor.text = exam.supervisor
        }
    }
}
