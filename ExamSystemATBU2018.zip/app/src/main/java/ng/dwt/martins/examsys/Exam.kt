package ng.dwt.martins.examsys

import java.util.*

class Exam(
    var course: String? = null,
    var supervisor: String? = null,
    val venue: String? = null,
    val date: Date
)